l = ['\n*Northern Region:*', '1', '2', '3']

l[:1]
l = l[:1]
l.insert(1,'Most Stations')

NZareas = {'Ang Mo Kio': ['Ang Mo Kio','Yio Chu Kang'],
           'Bishan': ['Bishan', 'Marymount'],
           'Sembawang': ['Sembawang','Canberra'],
           'Sungei Kadut': ['Kranji'],
           'Toa Payoh': ['Braddell','Toa Payoh','Caldecott'],
           'Woodlands': ['Marsiling','Woodlands','Admiralty'],
           'Yishun': ['Khatib']}
print(len(NZareas))
print(l)
