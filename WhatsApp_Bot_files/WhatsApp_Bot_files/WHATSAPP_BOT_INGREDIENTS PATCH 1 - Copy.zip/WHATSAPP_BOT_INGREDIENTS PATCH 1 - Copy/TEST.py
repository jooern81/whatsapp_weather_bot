# -*- coding: utf-8 -*-
"""
Created on Fri May  3 17:42:29 2019

@author: chinjooern
"""

if '2230' < '1744':
    print ('Yes')